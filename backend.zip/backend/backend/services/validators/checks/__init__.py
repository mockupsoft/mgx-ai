# -*- coding: utf-8 -*-
"""Validation checks module."""

__all__ = []
