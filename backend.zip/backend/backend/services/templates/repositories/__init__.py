"""
Repositories for Template and Prompt Library System.

This module provides data access layer for:
- Reusable module templates
- Prompt templates  
- Architecture Decision Records
"""
