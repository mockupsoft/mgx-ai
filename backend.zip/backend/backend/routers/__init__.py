# -*- coding: utf-8 -*-
"""Backend package initialization."""

from . import sandbox
from .quality_gates import router as quality_gates_router
from .rbac import router as rbac_router
from .audit import router as audit_router
from .secrets import router as secrets_router
from .generator import router as generator_router
from .artifacts import router as artifacts_router
from .costs import router as costs_router
from .validators import router as validators_router
from .templates import router as templates_router
from .knowledge import router as knowledge_router
from .llm import router as llm_router
from .escalation import router as escalation_router
from .observability import router as observability_router
from .file_approvals import router as file_approvals_router
from .webhooks import router as webhooks_router
from .pull_requests import router as pull_requests_router
from .issues import router as issues_router
from .activity import router as activity_router
from .branches import router as branches_router
from .diffs import router as diffs_router

# Legacy routers (kept for backwards compatibility)
from .health import router as health_router
from .workspaces import router as workspaces_router
from .projects import router as projects_router
from .repositories import router as repositories_router
from .tasks import router as tasks_router
from .runs import router as runs_router
from .metrics import router as metrics_router
from .agents import router as agents_router
from .workflows import router as workflows_router
from .ws import router as ws_router


__all__ = [
    "sandbox", 
    "quality_gates_router",
    "rbac_router", 
    "audit_router",
    "secrets_router",
    "generator_router",
    "artifacts_router",
    "costs_router",
    "validators_router",
    "templates_router",
    "knowledge_router",
    "llm_router",
    "escalation_router",
    "observability_router",
    "file_approvals_router",
    "health_router",
    "workspaces_router",
    "projects_router", 
    "repositories_router",
    "tasks_router",
    "runs_router",
    "metrics_router",
    "agents_router",
    "workflows_router",
    "ws_router",
    "webhooks_router",
    "pull_requests_router",
    "issues_router",
    "activity_router",
    "branches_router",
    "diffs_router",
]